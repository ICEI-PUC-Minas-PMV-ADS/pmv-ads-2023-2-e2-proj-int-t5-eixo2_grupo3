﻿using Microsoft.EntityFrameworkCore;

namespace mf_ecoEmpreendedor_2023.Models
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<Usuario> Usuarios { get; set; }
    }
}
